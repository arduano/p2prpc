"use strict";
/**
 * iroh-http-node — Node.js entry point.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TXT_KEY_RELAY = exports.TXT_KEY_PUBLIC_KEY = exports.TXT_KEY_ADDRESS = exports.SecretKey = exports.PublicKey = exports.IROH_HTTP_SERVICE = exports.asIrohPeer = void 0;
exports.createNode = createNode;
const index_js_1 = require("./index.js");
const iroh_http_shared_1 = require("@momics/iroh-http-shared");
const adapter_1 = require("@momics/iroh-http-shared/adapter");
// ── Graceful shutdown tracking ─────────────────────────────────────────────────
const _liveEndpoints = new Set();
function _closeAllEndpoints(signal) {
    const handles = [..._liveEndpoints];
    _liveEndpoints.clear();
    if (handles.length === 0)
        return;
    const deadline = setTimeout(() => process.exit(128 + (signal === "SIGTERM" ? 15 : 2)), 2000);
    if (deadline.unref)
        deadline.unref();
    Promise.all(handles.map((h) => (0, index_js_1.closeEndpoint)(h, true).catch(() => { }))).then(() => {
        process.exit(0);
    });
}
process.once("SIGTERM", () => _closeAllEndpoints("SIGTERM"));
process.once("SIGINT", () => _closeAllEndpoints("SIGINT"));
// ── NodeAdapter ────────────────────────────────────────────────────────────────
class NodeAdapter extends adapter_1.IrohAdapter {
    #eh;
    #sessionFns;
    #serveStopRequested = false;
    constructor(endpointHandle) {
        super();
        this.#eh = endpointHandle;
        const eh = endpointHandle;
        this.#sessionFns = {
            connect: async (epHandle, nodeId, directAddrs) => (0, index_js_1.sessionConnect)(epHandle, nodeId, directAddrs ?? undefined),
            sessionAccept: async (epHandle) => {
                const res = await (0, index_js_1.sessionAccept)(epHandle);
                if (res === null)
                    return null;
                return { sessionHandle: res.sessionHandle, nodeId: res.nodeId };
            },
            createBidiStream: async (sessionHandle) => {
                const ffi = await (0, index_js_1.sessionCreateBidiStream)(eh, sessionHandle);
                return {
                    readHandle: ffi.readHandle,
                    writeHandle: ffi.writeHandle,
                };
            },
            nextBidiStream: async (sessionHandle) => {
                const ffi = await (0, index_js_1.sessionNextBidiStream)(eh, sessionHandle);
                return ffi
                    ? {
                        readHandle: ffi.readHandle,
                        writeHandle: ffi.writeHandle,
                    }
                    : null;
            },
            createUniStream: async (sessionHandle) => (0, index_js_1.sessionCreateUniStream)(eh, sessionHandle),
            nextUniStream: async (sessionHandle) => {
                const h = await (0, index_js_1.sessionNextUniStream)(eh, sessionHandle);
                return h ?? null;
            },
            sendDatagram: async (sessionHandle, data) => (0, index_js_1.sessionSendDatagram)(eh, sessionHandle, data),
            recvDatagram: async (sessionHandle) => {
                const buf = await (0, index_js_1.sessionRecvDatagram)(eh, sessionHandle);
                return buf ? new Uint8Array(buf) : null;
            },
            maxDatagramSize: async (sessionHandle) => (0, index_js_1.sessionMaxDatagramSize)(eh, sessionHandle) ?? null,
            closed: async (sessionHandle) => {
                const info = await (0, index_js_1.sessionClosed)(eh, sessionHandle);
                return { closeCode: Number(info.closeCode), reason: info.reason };
            },
            close: async (sessionHandle, closeCode, reason) => (0, index_js_1.sessionCloseHandle)(eh, sessionHandle, closeCode !== undefined ? BigInt(closeCode) : undefined, reason),
        };
    }
    // ── Body streaming ──────────────────────────────────────────────────────────
    nextChunk(handle) {
        // Sync fast path: if data is already buffered, skip async overhead.
        try {
            const chunk = (0, index_js_1.jsTryNextChunk)(this.#eh, handle);
            return Promise.resolve(chunk ? new Uint8Array(chunk) : null);
        }
        catch (error) {
            const classified = (0, iroh_http_shared_1.classifyError)(error);
            if (classified.code !== "INTERNAL" ||
                !classified.message.startsWith("try_next_chunk:")) {
                throw classified;
            }
            // Channel empty or lock contended — fall back to async.
            return (0, index_js_1.jsNextChunk)(this.#eh, handle);
        }
    }
    sendChunk(handle, chunk) {
        return (0, index_js_1.jsSendChunk)(this.#eh, handle, chunk);
    }
    finishBody(handle) {
        (0, index_js_1.jsFinishBody)(this.#eh, handle);
        return Promise.resolve();
    }
    cancelRequest(handle) {
        (0, index_js_1.jsCancelRequest)(this.#eh, handle);
        return Promise.resolve();
    }
    allocFetchToken(_endpointHandle) {
        return Promise.resolve((0, index_js_1.jsAllocFetchToken)(this.#eh));
    }
    cancelFetch(token) {
        (0, index_js_1.jsCancelInFlight)(this.#eh, token);
    }
    allocBodyWriter(_endpointHandle) {
        return (0, index_js_1.jsAllocBodyWriter)(this.#eh);
    }
    // ── Raw transport ───────────────────────────────────────────────────────────
    async rawFetch(endpointHandle, nodeId, url, method, headers, reqBodyHandle, fetchToken, directAddrs, fetchOptions) {
        const res = await index_js_1.rawFetch(endpointHandle, nodeId, url, method, headers, reqBodyHandle ?? null, fetchToken, directAddrs ?? null, fetchOptions?.timeoutMs ?? undefined, fetchOptions?.decompress ?? undefined, fetchOptions?.maxResponseBodyBytes ?? undefined);
        return {
            status: res.status,
            headers: res.headers,
            bodyHandle: res.bodyHandle,
            url: res.url,
        };
    }
    async rawServe(endpointHandle, options, callback) {
        // `napiRawServe` registers the native serve handle asynchronously. A
        // caller may close the JS ServeHandle before that registration completes,
        // in which case the first `napiStopServe` is necessarily a no-op. Remember
        // the request and retry it once registration is known to be complete.
        this.#serveStopRequested = false;
        // #119: Track in-flight handler tasks so waitServeStop drains them before resolving.
        const pending = new Set();
        try {
            await (0, index_js_1.rawServe)(endpointHandle, (options.serveOptions ?? null), (payload) => {
                const typed = payload;
                const task = callback(typed)
                    .then((head) => {
                    try {
                        (0, index_js_1.rawRespond)(endpointHandle, typed.reqHandle, head.status, head.headers);
                    }
                    catch (respondErr) {
                        console.error("[iroh-http-node] rawRespond failed:", respondErr);
                    }
                })
                    .catch((err) => {
                    console.error("[iroh-http-node] serve handler error:", err);
                    try {
                        (0, index_js_1.rawRespond)(endpointHandle, typed.reqHandle, 500, []);
                    }
                    catch (respondErr) {
                        console.error("[iroh-http-node] rawRespond (fallback 500) failed:", respondErr);
                    }
                });
                pending.add(task);
                task.finally(() => pending.delete(task));
            }, options.onConnectionEvent ?? null);
            if (this.#serveStopRequested)
                (0, index_js_1.stopServe)(endpointHandle);
            await (0, index_js_1.waitServeStop)(endpointHandle);
            await Promise.allSettled([...pending]);
        }
        finally {
            this.#serveStopRequested = false;
        }
    }
    // ── Lifecycle ───────────────────────────────────────────────────────────────
    closeEndpoint(handle, force) {
        _liveEndpoints.delete(handle);
        return (0, index_js_1.closeEndpoint)(handle, force ?? null);
    }
    stopServe(handle) {
        this.#serveStopRequested = true;
        (0, index_js_1.stopServe)(handle);
    }
    waitEndpointClosed(handle) {
        return (0, index_js_1.waitEndpointClosed)(handle);
    }
    // ── Address / stats ─────────────────────────────────────────────────────────
    async nodeAddr(handle) {
        const info = (0, index_js_1.nodeAddr)(handle);
        return { id: info.id, addrs: info.addrs };
    }
    async nodeTicket(handle) {
        return (0, index_js_1.nodeTicket)(handle);
    }
    async homeRelay(handle) {
        return (0, index_js_1.homeRelay)(handle) ?? null;
    }
    async discoveryInfo(handle) {
        const info = (0, index_js_1.discoveryInfo)(handle);
        return {
            nodeId: info.nodeId,
            directAddress: info.directAddress ?? null,
            directAddresses: info.directAddresses ?? [],
            relayUrl: info.relayUrl ?? null,
        };
    }
    async peerInfo(handle, nodeId) {
        const info = await (0, index_js_1.peerInfo)(handle, nodeId);
        return info
            ? { id: info.id, addrs: info.addrs }
            : null;
    }
    async peerStats(handle, nodeId) {
        const stats = await (0, index_js_1.peerStats)(handle, nodeId);
        if (!stats)
            return null;
        return {
            relay: stats.relay,
            relayUrl: stats.relayUrl ?? null,
            paths: stats.paths,
            rttMs: stats.rttMs ?? null,
            bytesSent: stats.bytesSent ?? null,
            bytesReceived: stats.bytesReceived ?? null,
            lostPackets: stats.lostPackets ?? null,
            sentPackets: stats.sentPackets ?? null,
            congestionWindow: stats.congestionWindow ?? null,
        };
    }
    async stats(handle) {
        const s = (0, index_js_1.endpointStats)(handle);
        return {
            activeReaders: Number(s.activeReaders),
            activeWriters: Number(s.activeWriters),
            activeSessions: Number(s.activeSessions),
            totalHandles: Number(s.totalHandles),
            poolSize: Number(s.poolSize),
            activeConnections: Number(s.activeConnections),
            activeRequests: Number(s.activeRequests),
            activePathSubscriptions: Number(s.activePathSubscriptions),
            activePathWatchers: Number(s.activePathWatchers),
        };
    }
    // ── Sessions ────────────────────────────────────────────────────────────────
    get sessionFns() {
        return this.#sessionFns;
    }
    // ── mDNS discovery ──────────────────────────────────────────────────────────
    async browsePeers(handle, serviceName) {
        return (0, index_js_1.browsePeers)(handle, serviceName);
    }
    async browsePeersNext(browseHandle) {
        const ev = await (0, index_js_1.browsePeersNext)(browseHandle);
        if (!ev)
            return null;
        return {
            type: ev.isActive ? "discovered" : "expired",
            nodeId: ev.nodeId,
            addrs: ev.addrs,
        };
    }
    browsePeersClose(browseHandle) {
        (0, index_js_1.browsePeersClose)(browseHandle);
    }
    async advertisePeer(handle, serviceName) {
        return (0, index_js_1.advertisePeer)(handle, serviceName);
    }
    advertisePeerClose(advertiseHandle) {
        (0, index_js_1.advertisePeerClose)(advertiseHandle);
    }
    // ── Generic DNS-SD ──────────────────────────────────────────────────────────
    async advertise(config) {
        return (0, index_js_1.advertise)({
            serviceName: config.serviceName,
            instanceName: config.instanceName,
            port: config.port,
            addrs: config.addrs ?? [],
            txt: config.txt ?? {},
            protocol: config.protocol,
        });
    }
    advertiseClose(advertiseHandle) {
        (0, index_js_1.advertiseClose)(advertiseHandle);
    }
    async browse(serviceName, protocol) {
        return (0, index_js_1.browse)(serviceName, protocol);
    }
    async browseNext(browseHandle) {
        const rec = await (0, index_js_1.browseNext)(browseHandle);
        if (!rec)
            return null;
        return {
            isActive: rec.isActive,
            serviceType: rec.serviceType,
            instanceName: rec.instanceName,
            host: rec.host ?? undefined,
            port: rec.port,
            addrs: rec.addrs,
            txt: rec.txt,
        };
    }
    browseClose(browseHandle) {
        (0, index_js_1.browseClose)(browseHandle);
    }
    // ── Transport events ────────────────────────────────────────────────────────
    startTransportEvents(endpointHandle, callback) {
        void (0, index_js_1.startTransportEvents)(endpointHandle, (json) => {
            try {
                callback(JSON.parse(json));
            }
            catch (err) {
                console.error("[iroh-http-node] transport event callback error:", err);
            }
        });
    }
    async nextPathChange(endpointHandle, nodeId, subscriptionId) {
        const json = await (0, index_js_1.nextPathChange)(endpointHandle, nodeId, subscriptionId);
        if (json === null || json === undefined)
            return null;
        return JSON.parse(json);
    }
    unsubscribePathChanges(endpointHandle, nodeId, subscriptionId) {
        (0, index_js_1.unsubscribePathChanges)(endpointHandle, nodeId, subscriptionId);
        return Promise.resolve();
    }
}
// ── Public API ────────────────────────────────────────────────────────────────
var iroh_http_shared_2 = require("@momics/iroh-http-shared");
Object.defineProperty(exports, "asIrohPeer", { enumerable: true, get: function () { return iroh_http_shared_2.asIrohPeer; } });
Object.defineProperty(exports, "IROH_HTTP_SERVICE", { enumerable: true, get: function () { return iroh_http_shared_2.IROH_HTTP_SERVICE; } });
Object.defineProperty(exports, "PublicKey", { enumerable: true, get: function () { return iroh_http_shared_2.PublicKey; } });
Object.defineProperty(exports, "SecretKey", { enumerable: true, get: function () { return iroh_http_shared_2.SecretKey; } });
Object.defineProperty(exports, "TXT_KEY_ADDRESS", { enumerable: true, get: function () { return iroh_http_shared_2.TXT_KEY_ADDRESS; } });
Object.defineProperty(exports, "TXT_KEY_PUBLIC_KEY", { enumerable: true, get: function () { return iroh_http_shared_2.TXT_KEY_PUBLIC_KEY; } });
Object.defineProperty(exports, "TXT_KEY_RELAY", { enumerable: true, get: function () { return iroh_http_shared_2.TXT_KEY_RELAY; } });
async function createNode(options) {
    const keyBytes = options?.key
        ? options.key instanceof Uint8Array
            ? options.key
            : options.key.toBytes()
        : undefined;
    const { relayMode, relays, relayAuthToken, disableNetworking } = (0, iroh_http_shared_1.normaliseRelayMode)(options?.relay);
    const discovery = (0, iroh_http_shared_1.normaliseDiscovery)(options?.discovery);
    const compression = (0, iroh_http_shared_1.normaliseCompression)(options?.compression);
    const disableNetworkingFinal = disableNetworking ||
        (options?.disableNetworking ?? false);
    const bindAddrs = options?.bindAddr
        ? Array.isArray(options.bindAddr) ? options.bindAddr : [options.bindAddr]
        : undefined;
    const info = await (0, index_js_1.createEndpoint)(options
        ? {
            key: keyBytes,
            idleTimeout: options.connections?.idleTimeoutMs,
            relayMode,
            relays: relays ?? undefined,
            relayAuthToken,
            bindAddrs,
            dnsDiscovery: discovery.dnsServerUrl ?? undefined,
            dnsDiscoveryEnabled: discovery.dnsEnabled,
            channelCapacity: options.internals?.channelCapacity,
            maxChunkSizeBytes: options.internals?.maxChunkSizeBytes,
            handleTtl: options.internals?.handleTtl,
            maxPooledConnections: options.connections?.maxPooled,
            poolIdleTimeoutMs: options.connections?.poolIdleTimeoutMs,
            disableNetworking: disableNetworkingFinal,
            proxyUrl: options.proxy?.url,
            proxyFromEnv: options.proxy?.fromEnv,
            keylog: options.debug?.keylog,
            compressionLevel: compression.level,
            compressionMinBodyBytes: compression.minBodyBytes,
            maxHeaderBytes: options.limits?.maxHeaderBytes,
        }
        : undefined).catch((e) => {
        throw (0, iroh_http_shared_1.classifyBindError)(e);
    });
    const eh = info.endpointHandle;
    _liveEndpoints.add(eh);
    const adapter = new NodeAdapter(eh);
    const nativeClosed = (0, index_js_1.waitEndpointClosed)(info.endpointHandle);
    return iroh_http_shared_1.IrohNode._create(adapter, {
        endpointHandle: info.endpointHandle,
        nodeId: info.nodeId,
    }, options, nativeClosed);
}
//# sourceMappingURL=lib.js.map