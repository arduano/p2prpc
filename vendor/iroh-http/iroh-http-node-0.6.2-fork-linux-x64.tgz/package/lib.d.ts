/**
 * iroh-http-node — Node.js entry point.
 */
import { type DiscoveryInfo, IrohNode, type IrohNodeWithSecret, type NodeOptions, type SecretKey } from "@momics/iroh-http-shared";
import type { DnsSdProtocol, ServiceConfig, ServiceRecord } from "@momics/iroh-http-shared";
export { asIrohPeer, IROH_HTTP_SERVICE, PublicKey, SecretKey, TXT_KEY_ADDRESS, TXT_KEY_PUBLIC_KEY, TXT_KEY_RELAY, } from "@momics/iroh-http-shared";
export type { DnsSdAdvertiseOptions, DnsSdBrowseOptions, } from "@momics/iroh-http-shared";
export type { DnsSdProtocol, IrohNode, IrohNodeWithSecret, NodeOptions, ServiceConfig, ServiceRecord, };
export type { DiscoveryInfo };
/**
 * Create an Iroh node — the entry point for peer-to-peer HTTP.
 *
 * A node is both client and server: call {@link IrohNode.fetch} to send requests
 * to peers and {@link IrohNode.serve} to handle incoming ones. Each node has a
 * stable Ed25519 identity ({@link IrohNode.publicKey}) that peers use to address
 * it — there is no DNS.
 *
 * @param options Optional configuration ({@link NodeOptions}). Omit `key` to
 *   generate a fresh identity; pass a saved `key` to keep a stable node ID across
 *   restarts. Relay, discovery, and tuning are all configured here.
 * @returns A ready-to-use {@link IrohNode}. When you pass a `key`, the returned
 *   node's `secretKey` is non-optional ({@link IrohNodeWithSecret}); omit `key`
 *   and the natively generated identity is never surfaced, so `secretKey` is
 *   `undefined`. To persist an identity, generate a key and pass it back in.
 *
 * @example
 * ```ts
 * import { createNode } from "@momics/iroh-http-node";
 *
 * const node = await createNode();
 * const server = node.serve((req) => new Response("hello"));
 * const res = await node.fetch(`httpi://${peerId}/`);
 * console.log(await res.text());
 * await node.close();
 * ```
 */
export declare function createNode(options: NodeOptions & {
    key: SecretKey | Uint8Array;
}): Promise<IrohNodeWithSecret>;
export declare function createNode(options?: NodeOptions): Promise<IrohNode>;
//# sourceMappingURL=lib.d.ts.map